function printver() {
    document.getElementById("docversion").innerHTML=" v2.2.0.19";
    document.getElementById("docdate").innerHTML="2019 Nov 20";
}
